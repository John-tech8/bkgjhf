document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('profitCalcForm');
    const resultDiv = document.getElementById('calculatorResult');
    
    // Crop data mappings
    const cropData = {
        'paddy': { name: 'நெல் (Paddy)', yieldPerAcre: 25, unit: 'bags', pricePerUnit: 1200 },
        'groundnut': { name: 'நிலக்கடலை (Groundnut)', yieldPerAcre: 15, unit: 'bags', pricePerUnit: 2500 },
        'cotton': { name: 'பருத்தி (Cotton)', yieldPerAcre: 10, unit: 'quintals', pricePerUnit: 6000 },
        'sugarcane': { name: 'கரும்பு (Sugarcane)', yieldPerAcre: 40, unit: 'tons', pricePerUnit: 3000 }
    };

    if (form) {
        form.addEventListener('submit', (e) => {
            e.preventDefault();
            
            const cropKey = document.getElementById('cropName').value;
            const landSize = parseFloat(document.getElementById('landSize').value);
            const seedCost = parseFloat(document.getElementById('seedCost').value);
            
            const data = cropData[cropKey];
            
            // Logic calculation
            const totalYield = data.yieldPerAcre * landSize;
            const grossIncome = totalYield * data.pricePerUnit;
            const expectedProfit = grossIncome - seedCost;
            
            // Format numbers to Indian currency style
            const formatter = new Intl.NumberFormat('en-IN', {
                style: 'currency',
                currency: 'INR',
                maximumFractionDigits: 0
            });
            
            // Display Results
            document.getElementById('resCrop').textContent = data.name;
            document.getElementById('resLand').textContent = landSize;
            document.getElementById('resYield').textContent = `${totalYield} ${data.unit}`;
            
            document.getElementById('resProfit').textContent = formatter.format(expectedProfit);
            
            resultDiv.style.display = 'block';
            
            // Smooth scroll to result
            resultDiv.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        });
    }
});
