document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('cropRecForm');
    const resultDiv = document.getElementById('recommendationResult');
    const list = document.getElementById('recommendedCropsList');

    if (form) {
        form.addEventListener('submit', (e) => {
            e.preventDefault();
            
            const soil = document.getElementById('soilType').value;
            // Example logic requested in prompt:
            // Red Soil → Groundnut, Millets
            // Clay Soil → Paddy
            // Black Soil → Cotton, Soybean
            // Sandy Soil → Groundnut, Watermelon
            
            let crops = [];
            
            switch(soil) {
                case 'red':
                    crops = ['நிலக்கடலை (Groundnut)', 'சிறுதானியங்கள் (Millets)'];
                    break;
                case 'clay':
                    crops = ['நெல் (Paddy)'];
                    break;
                case 'black':
                    crops = ['பருத்தி (Cotton)', 'சோயாபீன் (Soybean)'];
                    break;
                case 'sandy':
                    crops = ['நிலக்கடலை (Groundnut)', 'தர்பூசணி (Watermelon)'];
                    break;
                default:
                    crops = ['உள்ளூர் வேளாண் துறையை அணுகவும் (Contact Local Dept)'];
            }
            
            list.innerHTML = '';
            crops.forEach(crop => {
                const li = document.createElement('li');
                li.textContent = crop;
                list.appendChild(li);
            });
            
            resultDiv.style.display = 'block';
        });
    }
});
