const translations = {
    en: {
        home: "Home",
        services: "Services",
        ai_help: "AI Assistant",
        contact: "Contact",
        register: "Register",
        lang_toggle: "தமிழ் | EN",
        hero_title: "Your Agriculture,<br>Our Pride!",
        hero_desc: "An integrated digital hub for Tamil Nadu farmers. Welcome to explore market trends, subsidies, and technologies.",
        join_now: "Join Now",
        learn_more: "Learn More",
        // Add more keys as needed for other pages
        market_price: "Market Price",
        weather: "Weather",
        schemes: "Government Schemes",
        crop_mgmt: "Crop Management",
        pest_mgmt: "Pest Management",
        
        // Addon features
        crop_recommendation: "Crop Recommendation",
        profit_calculator: "Profit Calculator",
        equipment_guide: "Equipment Guide",
        
        recommend_crop: "Recommend Crop",
        soil_type: "Soil Type",
        season: "Season",
        location: "Location",
        
        crop_name: "Crop Name",
        land_size: "Land Size (acres)",
        seed_cost: "Seed Cost (₹)",
        calculate: "Calculate"
    },
    ta: {
        home: "முகப்பு (Home)",
        services: "சேவைகள் (Services)",
        ai_help: "AI உதவி",
        contact: "Contact",
        register: "பதிவு செய்க (Register)",
        lang_toggle: "EN | தமிழ்",
        hero_title: "உங்கள் வேளாண்மை,<br>எங்கள் பெருமை!",
        hero_desc: "தமிழக விவசாயிகளுக்கான ஒரு ஒருங்கிணைந்த டிஜிட்டல் மையம். சந்தை நிலவரம், மானியங்கள் மற்றும் தொழில்நுட்பங்களை அறிந்துகொள்ள உங்களை அன்போடு வரவேற்கிறோம்.",
        join_now: "இப்போதே இணையுங்கள்",
        learn_more: "மேலும் அறிய",
        
        market_price: "சந்தை விலை நிலவரம்",
        weather: "வானிலை அறிக்கை",
        schemes: "அரசு திட்டங்கள் & மானியம்",
        crop_mgmt: "நவீன வேளாண் குறிப்புகள்",
        pest_mgmt: "பூச்சி & நோய் மேலாண்மை",
        
        // Addon features
        crop_recommendation: "பயிர் பரிந்துரை (Crop Rec.)",
        profit_calculator: "லாப கணக்கீட்டான் (Profit Calc)",
        equipment_guide: "உபகரணங்கள் வழிகாட்டி (Equipment Guide)",
        
        recommend_crop: "பரிந்துரைக்க",
        soil_type: "மண் வகை",
        season: "பருவம்",
        location: "பகுதி",
        
        crop_name: "பயிரின் பெயர்",
        land_size: "நிலப்பரப்பு அளவு (ஏக்கரில்)",
        seed_cost: "விதையின் செலவு (₹)",
        calculate: "கணக்கிடு"
    }
};

document.addEventListener('DOMContentLoaded', () => {
    const langToggleBtn = document.getElementById('lang-toggle');
    
    // Check local storage for language preference, default to Tamil
    let currentLang = localStorage.getItem('site_lang') || 'ta';
    
    // Function to apply translations
    const applyTranslations = (lang) => {
        const elements = document.querySelectorAll('[data-i18n]');
        elements.forEach(el => {
            const key = el.getAttribute('data-i18n');
            if (translations[lang] && translations[lang][key]) {
                if (el.tagName.toLowerCase() === 'input' && el.getAttribute('placeholder')) {
                    el.setAttribute('placeholder', translations[lang][key]);
                } else {
                    el.innerHTML = translations[lang][key];
                }
            }
        });
        
        // Update document lang attribute
        document.documentElement.lang = lang;
        
        if (langToggleBtn) {
            langToggleBtn.innerHTML = translations[lang]['lang_toggle'];
        }
    };
    
    // Apply initial translations
    applyTranslations(currentLang);
    
    // Toggle button event listener
    if (langToggleBtn) {
        langToggleBtn.addEventListener('click', () => {
            currentLang = currentLang === 'ta' ? 'en' : 'ta';
            localStorage.setItem('site_lang', currentLang);
            applyTranslations(currentLang);
        });
    }
});
